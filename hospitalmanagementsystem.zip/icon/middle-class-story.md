Once I was seven years old, my papa told me
Go make yourself some friends or you'll be lonely
Once I was seven years old

It was a big big world, but we thought we were bigger
Pushing each other to score runs like winners
I wanted to be just like Kohli and Dhoni
Once I was seven years old

Once I was eleven years old, my story started
Watching her from afar, but stayed broken-hearted
Couldn't speak up because I felt so small
My family's struggles kept me behind the wall
Once I was eleven years old

Once I was twenty years old
My life was coding and dreams had to be sold
Engineering classes filled with theory's haze
While my passion for cricket slowly fades
Once I was twenty years old

Soon I'll be twenty-five
Walking down the aisle with someone by my side
Not love but duty, that's what they all say
Society's pressure made me walk this way
Soon I'll be twenty-five

Soon I'll be thirty years old
My desk job killing me, but that's how it goes
Nine to five grind, with a boss who never cares
Middle class dreams lost in system's snares
Soon I'll be thirty years old

Soon I'll be thirty-three
A father to a son I no longer get to see
False cases piling up, my savings all gone
My maa and papa drained, while justice moves on
Soon I'll be thirty-three

Once I was seven years old, my papa told me
"Go make yourself some friends or you'll be lonely"
Once I was seven years old

I made a video for my son to see
Telling him the truth of what happened to me
Corrupt system, broken dreams, and lies
This is my story before I say goodbye
This was my life's song

Once I was seven years old
